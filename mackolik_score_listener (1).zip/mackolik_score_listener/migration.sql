-- Supabase SQL Editor'da çalıştır (tek seferlik)
-- live_matches tablosuna score_source kolonu ekle
ALTER TABLE live_matches
  ADD COLUMN IF NOT EXISTS score_source TEXT DEFAULT 'apifootball';

-- Opsiyonel: Hangi maçın hangi kaynaktan güncellendiğini görmek için indeks
CREATE INDEX IF NOT EXISTS idx_live_matches_score_source
  ON live_matches(score_source);
